root=/anvil/scratch/x-colson1/abid_bot_q1.99_sol_01

datadir=/anvil/scratch/x-colson1/bhtD2.0_K1_g1.60_fAJS0.80_000_000_q1.99_l4.10_r0.40_sol_01

cd $root/h5data
for d in $datadir/beta100/2*; do    ln -s "$d" "3d_data_$(basename "$d")";done
cp $datadir/*on .

cd horizon/all_horizon/
cp -u $datadir/beta100/Horizon/*.gp .

cd $root

echo "Setup complete."